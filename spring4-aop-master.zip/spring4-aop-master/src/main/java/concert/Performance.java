package concert;

public interface Performance {
  public void perform();
}
