package concert;

public interface Encoreable {
  void performEncore();
}
