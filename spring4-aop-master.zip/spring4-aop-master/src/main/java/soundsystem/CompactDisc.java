package soundsystem;

public interface CompactDisc {
  void playTrack(int id);
}
