package nba;

import org.springframework.stereotype.Component;

@Component
public class GameImpl implements Game {

  @Override
  public void play() {}

}
