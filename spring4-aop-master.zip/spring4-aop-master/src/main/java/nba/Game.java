package nba;

public interface Game {
  void play();
}
